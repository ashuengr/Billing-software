package com.cg.registration.stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.cg.registration.pagebeans.RegistrationPage;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentStepDefinition {
	private WebDriver driver;
	private RegistrationPage regBean;

	@Before
	public void openBrowser() {
		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "D:\\3000176_Girish_Jangid\\chromedriver.exe" ); driver=new ChromeDriver();
		 * driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 * 
		 * 
		 * driver.
		 * get("D:\\3000176_Girish_Jangid\\BDDCucumberSelenium\\Set B\\PaymentDetails.html"
		 * );
		 */
	}

	//Method for handling alert message
	public void callingAlertFunction() throws InterruptedException {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("TestCase :4 " + alertMessage);
		driver.close();
	}
	@Given("^user is on the payment page$")
	public void user_is_on_the_payment_page() throws Throwable {
		openBrowser();
	}

	@Then("^check the title of the payment page$")
	public void check_the_title_of_the_payment_page() throws Throwable {
		if(driver.getTitle().equals("Payment Details")) 
			System.out.println("TestCase :1 Title Matched");
		else
			System.out.println("Title Not Matched");
	}

	//Blank CardHolder Name
	@When("^user leaves CardHolder Name blank and clicks on Make Payment$")
	public void user_leaves_CardHolder_Name_blank_and_clicks_on_Make_Payment() throws Throwable {
		regBean.setPfCardHolderName("");
		regBean.setPfMakePayment();
	}

	@Then("^display alert box with CardHolder Name empty message$")
	public void display_alert_box_with_CardHolder_Name_empty_message() throws Throwable {
		callingAlertFunction();
	}

	//Blank DebitCard Number
	@When("^user leaves DebitCard Number blank and clicks on Make Payment$")
	public void user_leaves_DebitCard_Number_blank_and_clicks_on_Make_Payment() throws Throwable {
		regBean.setPfCardHolderName("Girish Jangid");
		regBean.setPfCardNumber("");
		regBean.setPfMakePayment();
	}

	@Then("^display alert box with DebitCard Number empty message$")
	public void display_alert_box_with_DebitCard_Number_empty_message() throws Throwable {
		callingAlertFunction();
	}

	//Blank Expiration month
	@When("^user leaves Expiration Month blank and clicks on Make Payment$")
	public void user_leaves_Expiration_Month_blank_and_clicks_on_Make_Payment() throws Throwable {
		regBean.setPfCardHolderName("Girish Jangid");
		regBean.setPfCardNumber("45612378903214");
		regBean.setPfExpMonth("");
		regBean.setPfMakePayment();
	}

	@Then("^display alert box with Expiration Month empty message$")
	public void display_alert_box_with_Expiration_Month_empty_message() throws Throwable {
		callingAlertFunction();
	}

	//blank expiration year
	@When("^user leaves Expiration Year blank and clicks on Make Payment$")
	public void user_leaves_Expiration_Year_blank_and_clicks_on_Make_Payment() throws Throwable {
		regBean.setPfCardHolderName("Girish Jangid");
		regBean.setPfCardNumber("45612378903214");
		regBean.setPfExpMonth("12");
		regBean.setPfExpYear("");
		regBean.setPfMakePayment();
	}

	@Then("^display alert box with Expiration Year empty message$")
	public void display_alert_box_with_Expiration_Year_empty_message() throws Throwable {
		callingAlertFunction();
	}

	//user enters all valid data and success alert message comes
	@When("^user enters valid details and clicks on Make Payment$")
	public void user_enters_valid_details_and_clicks_on_Make_Payment() throws Throwable {
		regBean.setPfCardHolderName("Girish Jangid");
		regBean.setPfCardNumber("45612378903214");
		regBean.setPfExpMonth("12");
		regBean.setPfExpYear("30");
		regBean.setPfMakePayment();
	}

	@Then("^display alert box with payment success message$")
	public void display_alert_box_with_payment_success_message() throws Throwable {
		callingAlertFunction();
	}
	
}
